package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
/*
 * Vien Nguyen
 * CST235
 *  Book class
 * This class is a model of book.
 */
@ManagedBean
@ViewScoped
@XmlRootElement(name = "book")
public class Book {
	//book id
	int bookId;
	//book title
	@NotNull(message = "Book title is required.")
	@Size(min = 4, max = 50)
	String title;
	//book's isbn
	String isbn;
	//book author id
	int authorId;
	//book publisher
	String publisher;
	//book edition
	int edition;
	//type of format
	String type;
	//book category id
	int categoryId;
	//coverimage of the book
	String coverImage;
	//Default constructor
	public Book() {
		// TODO Auto-generated constructor stub
	}
	//Constructor with parameters
	public Book(int bookId, String title, String isbn, int authorId, String publisher, int edition, String type,
			int categoryId, String coverImage) {
		
		this.bookId = bookId;
		this.title = title;
		this.isbn = isbn;
		this.authorId = authorId;
		this.publisher = publisher;
		this.edition = edition;
		this.type = type;
		this.categoryId = categoryId;
		this.coverImage = coverImage;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getEdition() {
		return edition;
	}

	public void setEdition(int edition) {
		this.edition = edition;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}
	
	
}

