package business;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import beans.Book;
import data.DataAccessInterface;

/*Vien Nguyen
 * CST235 TUE-THURS MileStone 5
 * 
 * This is the Rests service class, 
 * will provide the communicating ports for outside services
 * The class wihh host 2 services that allow outside call of get the book list,
 * and add new book to database.
 * */

@RequestScoped
@Path("/books")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class BookRestService {

	// Initiate and call Data Access Interface
	@Inject
	DataAccessInterface<Book> bookService;

	// Get the book list by getting json format
	@GET
	@Path("/get_book_json")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooksAsJson() {
		return bookService.findAll();
	}

	// Get the book list by getting xml format
	@GET
	@Path("/get_book_xml")
	@Produces(MediaType.APPLICATION_XML)
	public List<Book> getBooksAsXml() {
		return bookService.findAll();
	}
	// Add a new book into the database
	@POST
	@Path("/createBook")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createBook(Book book) {

		String message = "";
		if (bookService.create(book)) {
			message = "Add New book was created";
		} else {
			message = "Add New book was fail!";
		}
		return Response.status(Response.Status.OK).entity(message).build();
	}
	
	// Delete book from the database
	@DELETE
	@Path("deleteBook/{bookId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteBook(@PathParam ("bookId") int bookId ) {

		Book book = new Book();
		book.setBookId(bookId);
		String message = "";
		if (bookService.delete(book)) {
			message = "The book with id " + bookId + " was deleted";
		} else {
			message = "There was no book with such bookId deleted!";
		}
		return Response.status(Response.Status.OK).entity(message).build();
	}
}
